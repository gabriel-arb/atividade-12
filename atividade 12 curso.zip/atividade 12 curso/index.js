
const header = document.querySelector('header');
const tituloH1 = document.createElement('h1');
tituloH1.textContent = 'Título do Site';
header.appendChild(tituloH1);


const main = document.querySelector('main');


const div1 = document.createElement('div');
div1.classList.add('div1'); 
const tituloH2Div1 = document.createElement('h2');
tituloH2Div1.textContent = 'Título da Div 1';
const paragrafoDiv1 = document.createElement('p');
paragrafoDiv1.textContent = 'Conteúdo da Div 1';
div1.appendChild(tituloH2Div1);
div1.appendChild(paragrafoDiv1);


const div2 = document.createElement('div');
div2.classList.add('div2'); 
const tituloH2Div2 = document.createElement('h2');
tituloH2Div2.textContent = 'Título da Div 2';
const paragrafoDiv2 = document.createElement('p');
paragrafoDiv2.textContent = 'Conteúdo da Div 2';
div2.appendChild(tituloH2Div2);
div2.appendChild(paragrafoDiv2);


main.appendChild(div1);
main.appendChild(div2);
